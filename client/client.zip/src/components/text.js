export const en = {
    name_uppercase: "AMANDA KENDERES"
}