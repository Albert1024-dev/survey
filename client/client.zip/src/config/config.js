const config = {
    serverURL: 'http://localhost:5000',
    secretKey: 'TalkType_Taku_Kapil',
};

module.exports = config;