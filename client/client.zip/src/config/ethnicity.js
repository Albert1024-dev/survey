const ethnicityData = [
    { value: 'asia', text: 'Asia' },
    { value: 'europe', text: 'Europe' },
    { value: 'africa', text: 'Africa' },
    { value: 'northamerica', text: 'North America' },
    { value: 'southamerica', text: 'South America' }
];

export default ethnicityData;